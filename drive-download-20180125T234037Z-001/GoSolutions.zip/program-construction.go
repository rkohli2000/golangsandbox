package main

import "env"

func main() {
    env.Vars()
}

